


#Steps

1. execute the script in BuildSkiResort.sql to build the SkiResort database.
2. execute the script in SkiResortScript.sql to build view, function, and procedure.
   Notice that you should modify the csv file path in the script to your local csv file
   path.
3. open .sln file with your Visual Studio 2017/2019, change the connectionString in app.config 
   to your local database connection String, including data source and  user name ,password (if you hava)
4. run the project by clicking the 'run' button on top of the Visual Studio IDE user interface.