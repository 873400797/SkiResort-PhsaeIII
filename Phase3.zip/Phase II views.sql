--SkiResortScript Written By Tianyang Yang
--Peer Review by Yicheng Wang
--Create Views
USE SkiResort;
GO 
-- Create views
IF EXISTS(
SELECT *
	From sys.views
	WHERE NAME = N'Class_Detail'
	)
DROP VIEW class_detail;
GO

CREATE view Class_Detail AS 
SELECT
	Class.ClassID,
	Class.ClassName,
	Class.Price,
	Class.LevelID,
	Class.InstructorID,
	Class.ResortID,
	Student.StudentID,
	Enrollment.EnrollmentDate 
FROM
	Class
	INNER JOIN Enrollment ON Class.ClassID = Enrollment.ClassID
	INNER JOIN Student ON Enrollment.StudentID = Student.StudentID
WITH CHECK OPTION;
GO
--Test View
SELECT *
FROM Class_Detail;

GO

-- Create Functions
IF EXISTS(SELECT * FROM sys.objects
	WHERE NAME = N'ufn_StudentLevel')
	DROP FUNCTION dbo.ufn_StudentLevel;
GO
CREATE functiON ufn_StudentLevel(@studentName CHAR(60))
RETURNS CHAR(30)
AS 
BEGIN 
	DECLARE @total_enrols INT;
	DECLARE @return_text CHAR(30);
	DECLARE @levelID INT;

	SELECT @total_enrols = COUNT(*) FROM Enrollment 
	INNER JOIN Student ON Enrollment.StudentID = Student.StudentID
	WHERE concat(Firstname,' ',LastName) = @studentName;

	IF @total_enrols = 0
		BEGIN
		set @return_text = 'No Enrolment'
		END
	ELSE
		BEGIN
			SELECT @levelID = MAX(levelID) 
			FROM class INNER JOIN  Enrollment ON class.ClassID = Enrollment.ClassID
			INNER JOIN Student ON Enrollment.StudentID = Student.StudentID
			WHERE CONCAT(Firstname,' ',LastName) = @studentName;
			SELECT @return_text = descriptiON FROM ClassLevel WHERE LevelID = @levelID;
		END
	RETURN @return_text;
END;
GO
--Test Function
SELECT dbo.ufn_StudentLevel('Jack Schmidt') AS 'StudentLevel';
SELECT dbo.ufn_StudentLevel('Test') AS 'StudentLevel';


-- Create Procedures

IF EXISTS(SELECT * FROM sys.objects
	WHERE NAME = N'usp_ClassEnrolsPerMonth')
	DROP PROCEDURE usp_ClassEnrolsPerMonth
GO
CREATE PROCEDURE usp_ClassEnrolsPerMonth(@classID INT = NULL)
AS 
BEGIN
DECLARE @ClassNum INT;
DECLARE @msg CHAR(255);
	IF @classID IS NULL
		BEGIN 
			SELECT 'Omitted parameter: The form to use for this procedure is:EXEC usp_ClassEnrolsPerMonth "<Class ID>"' AS 'Warning Message'
		END;
	ELSE
		BEGIN
			SELECT @ClassNum = COUNT(*) FROM Class WHERE ClassID = @classID;
			IF @ClassNum = 0
				BEGIN
				 SELECT 'The Class ID is Not Existed.' AS Error
				END 
			ELSE
			    BEGIN
				SELECT @ClassNum = COUNT(1) FROM Enrollment WHERE ClassID = @classID;
				IF @ClassNum = 0
					BEGIN
					 SELECT 'No Student Enrolled This Class.' AS Error
					END
				ELSE
					BEGIN
						SELECT MONTH(EnrollmentDate) AS Month, COUNT(StudentID) AS Student_num
						FROM Enrollment
						WHERE ClassID = @classID
						GROUP BY MONTH(EnrollmentDate)
				Order By 1;
					END;
				END
		END
	END
GO
--Test Procedure
EXEC usp_ClassEnrolsPerMonth;
EXEC usp_ClassEnrolsPerMonth 10;
EXEC usp_ClassEnrolsPerMonth 101;
