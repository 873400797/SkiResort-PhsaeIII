﻿Public Class ClassForm
    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub FillByToolStripButton_Click_1(sender As Object, e As EventArgs) Handles FillByToolStripButton.Click
        Try
            Me.ClassLevelTableAdapter.Fill(Me.SkiResortDataSet.ClassLevel)
            Me.InstructorTableAdapter.Fill(Me.SkiResortDataSet.Instructor)
            Me.ResortTableAdapter.Fill(Me.SkiResortDataSet.Resort)
            Me.GenderTableAdapter.Fill(Me.SkiResortDataSet.Gender)

            Me.ClassTableAdapter.FillBy(Me.SkiResortDataSet._Class, CType(ClassIDToolStripTextBox.Text, Integer))
            Me.StudentTableAdapter.FillBy(Me.SkiResortDataSet.Student, New System.Nullable(Of Integer)(CType(ClassIDToolStripTextBox.Text, Integer)))
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        Dim frmClassLevel As New ClassLevelForm
        frmClassLevel.ShowDialog()
    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick
        If (e.ColumnIndex = 0) Then
            Try
                Dim frmInventoryItem As New StudentForm
                Console.WriteLine(DataGridView1.Rows(e.RowIndex).Cells("StudentID").Value)
                frmInventoryItem.FillByStudentId(DataGridView1.Rows(e.RowIndex).Cells("StudentID").Value)
                frmInventoryItem.ShowDialog()
            Catch ex As Exception
                System.Windows.Forms.MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim frmSearchForm As New SearchForm
        frmSearchForm.ShowDialog()
    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub StudentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentToolStripMenuItem.Click
        Try
            Dim Student As New StudentForm
            Student.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ClassToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClassToolStripMenuItem.Click
        Try
            Dim ClassLevelToolStripMenuItem As New ClassForm
            ClassLevelToolStripMenuItem.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub SeachToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SeachToolStripMenuItem.Click
        Try
            Dim SearchToolStripMenuItem1 As New SearchForm
            SearchToolStripMenuItem1.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ClassLevelToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClassLevelToolStripMenuItem.Click
        Try
            Dim ClassLevelToolStripMenuItem As New ClassLevelForm
            ClassLevelToolStripMenuItem.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
