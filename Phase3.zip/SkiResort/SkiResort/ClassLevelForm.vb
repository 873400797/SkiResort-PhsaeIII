﻿Public Class ClassLevelForm
    Private Sub ClassLevel_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.ClassLevelTableAdapter.Fill(Me.SkiResortDataSet.ClassLevel)
        Catch ex As System.Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        Me.ClassLevelBindingSource.EndEdit()
        Me.ClassLevelTableAdapter.Update(Me.SkiResortDataSet.ClassLevel)
        MessageBox.Show("Saved")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub StudentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentToolStripMenuItem.Click
        Try
            Dim Student As New StudentForm
            Student.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ClassToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClassToolStripMenuItem.Click
        Try
            Dim ClassLevelToolStripMenuItem As New ClassForm
            ClassLevelToolStripMenuItem.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub SearchToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchToolStripMenuItem.Click
        Try
            Dim SearchToolStripMenuItem1 As New SearchForm
            SearchToolStripMenuItem1.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ClassLevelToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClassLevelToolStripMenuItem.Click
        Try
            Dim ClassLevelToolStripMenuItem As New ClassLevelForm
            ClassLevelToolStripMenuItem.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class