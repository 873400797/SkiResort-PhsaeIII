﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SearchForm
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle13 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle14 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle15 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SearchForm))
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.ClassIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ClassNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PriceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LevelIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.ClassLevelBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SkiResortDataSet = New SkiResort.SkiResortDataSet()
        Me.InstructorIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.InstructorBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ResortIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.ResortBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.EnrollmentDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ClassDetailBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DateTimePicker_Start = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker_End = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Class_DetailTableAdapter = New SkiResort.SkiResortDataSetTableAdapters.Class_DetailTableAdapter()
        Me.ClassLevelTableAdapter = New SkiResort.SkiResortDataSetTableAdapters.ClassLevelTableAdapter()
        Me.InstructorTableAdapter = New SkiResort.SkiResortDataSetTableAdapters.InstructorTableAdapter()
        Me.ResortTableAdapter = New SkiResort.SkiResortDataSetTableAdapters.ResortTableAdapter()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox_student = New System.Windows.Forms.ComboBox()
        Me.StudentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.StudentTableAdapter = New SkiResort.SkiResortDataSetTableAdapters.StudentTableAdapter()
        Me.Label_expense = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.AgentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClassToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClassLevelToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClassLevelBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SkiResortDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.InstructorBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ResortBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClassDetailBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        DataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle13.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle13
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ClassIDDataGridViewTextBoxColumn, Me.ClassNameDataGridViewTextBoxColumn, Me.PriceDataGridViewTextBoxColumn, Me.LevelIDDataGridViewTextBoxColumn, Me.InstructorIDDataGridViewTextBoxColumn, Me.ResortIDDataGridViewTextBoxColumn, Me.EnrollmentDateDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.ClassDetailBindingSource
        DataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle14.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle14
        Me.DataGridView1.Location = New System.Drawing.Point(13, 231)
        Me.DataGridView1.Name = "DataGridView1"
        DataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle15.Font = New System.Drawing.Font("SimSun", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        DataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle15
        Me.DataGridView1.RowTemplate.Height = 23
        Me.DataGridView1.Size = New System.Drawing.Size(763, 233)
        Me.DataGridView1.TabIndex = 0
        '
        'ClassIDDataGridViewTextBoxColumn
        '
        Me.ClassIDDataGridViewTextBoxColumn.DataPropertyName = "ClassID"
        Me.ClassIDDataGridViewTextBoxColumn.HeaderText = "ClassID"
        Me.ClassIDDataGridViewTextBoxColumn.Name = "ClassIDDataGridViewTextBoxColumn"
        '
        'ClassNameDataGridViewTextBoxColumn
        '
        Me.ClassNameDataGridViewTextBoxColumn.DataPropertyName = "ClassName"
        Me.ClassNameDataGridViewTextBoxColumn.HeaderText = "ClassName"
        Me.ClassNameDataGridViewTextBoxColumn.Name = "ClassNameDataGridViewTextBoxColumn"
        '
        'PriceDataGridViewTextBoxColumn
        '
        Me.PriceDataGridViewTextBoxColumn.DataPropertyName = "Price"
        Me.PriceDataGridViewTextBoxColumn.HeaderText = "Price"
        Me.PriceDataGridViewTextBoxColumn.Name = "PriceDataGridViewTextBoxColumn"
        '
        'LevelIDDataGridViewTextBoxColumn
        '
        Me.LevelIDDataGridViewTextBoxColumn.DataPropertyName = "LevelID"
        Me.LevelIDDataGridViewTextBoxColumn.DataSource = Me.ClassLevelBindingSource
        Me.LevelIDDataGridViewTextBoxColumn.DisplayMember = "Description"
        Me.LevelIDDataGridViewTextBoxColumn.HeaderText = "Level"
        Me.LevelIDDataGridViewTextBoxColumn.Name = "LevelIDDataGridViewTextBoxColumn"
        Me.LevelIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.LevelIDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.LevelIDDataGridViewTextBoxColumn.ValueMember = "LevelID"
        '
        'ClassLevelBindingSource
        '
        Me.ClassLevelBindingSource.DataMember = "ClassLevel"
        Me.ClassLevelBindingSource.DataSource = Me.SkiResortDataSet
        '
        'SkiResortDataSet
        '
        Me.SkiResortDataSet.DataSetName = "SkiResortDataSet"
        Me.SkiResortDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'InstructorIDDataGridViewTextBoxColumn
        '
        Me.InstructorIDDataGridViewTextBoxColumn.DataPropertyName = "InstructorID"
        Me.InstructorIDDataGridViewTextBoxColumn.DataSource = Me.InstructorBindingSource
        Me.InstructorIDDataGridViewTextBoxColumn.DisplayMember = "FirstName"
        Me.InstructorIDDataGridViewTextBoxColumn.HeaderText = "Instructor"
        Me.InstructorIDDataGridViewTextBoxColumn.Name = "InstructorIDDataGridViewTextBoxColumn"
        Me.InstructorIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.InstructorIDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.InstructorIDDataGridViewTextBoxColumn.ValueMember = "InstructorID"
        '
        'InstructorBindingSource
        '
        Me.InstructorBindingSource.DataMember = "Instructor"
        Me.InstructorBindingSource.DataSource = Me.SkiResortDataSet
        '
        'ResortIDDataGridViewTextBoxColumn
        '
        Me.ResortIDDataGridViewTextBoxColumn.DataPropertyName = "ResortID"
        Me.ResortIDDataGridViewTextBoxColumn.DataSource = Me.ResortBindingSource
        Me.ResortIDDataGridViewTextBoxColumn.DisplayMember = "ResortName"
        Me.ResortIDDataGridViewTextBoxColumn.HeaderText = "Resort"
        Me.ResortIDDataGridViewTextBoxColumn.Name = "ResortIDDataGridViewTextBoxColumn"
        Me.ResortIDDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.ResortIDDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.ResortIDDataGridViewTextBoxColumn.ValueMember = "ResortID"
        '
        'ResortBindingSource
        '
        Me.ResortBindingSource.DataMember = "Resort"
        Me.ResortBindingSource.DataSource = Me.SkiResortDataSet
        '
        'EnrollmentDateDataGridViewTextBoxColumn
        '
        Me.EnrollmentDateDataGridViewTextBoxColumn.DataPropertyName = "EnrollmentDate"
        Me.EnrollmentDateDataGridViewTextBoxColumn.HeaderText = "EnrollmentDate"
        Me.EnrollmentDateDataGridViewTextBoxColumn.Name = "EnrollmentDateDataGridViewTextBoxColumn"
        '
        'ClassDetailBindingSource
        '
        Me.ClassDetailBindingSource.DataMember = "Class_Detail"
        Me.ClassDetailBindingSource.DataSource = Me.SkiResortDataSet
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(398, 192)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Start Date: "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("SimSun", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label2.Location = New System.Drawing.Point(268, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(273, 20)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "Search Student's Classes"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(200, 110)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(95, 34)
        Me.Button1.TabIndex = 17
        Me.Button1.Text = "Search"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'DateTimePicker_Start
        '
        Me.DateTimePicker_Start.Location = New System.Drawing.Point(477, 186)
        Me.DateTimePicker_Start.Name = "DateTimePicker_Start"
        Me.DateTimePicker_Start.Size = New System.Drawing.Size(161, 20)
        Me.DateTimePicker_Start.TabIndex = 18
        '
        'DateTimePicker_End
        '
        Me.DateTimePicker_End.Location = New System.Drawing.Point(477, 131)
        Me.DateTimePicker_End.Name = "DateTimePicker_End"
        Me.DateTimePicker_End.Size = New System.Drawing.Size(161, 20)
        Me.DateTimePicker_End.TabIndex = 20
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(398, 131)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 13)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "End Date: "
        '
        'Class_DetailTableAdapter
        '
        Me.Class_DetailTableAdapter.ClearBeforeFill = True
        '
        'ClassLevelTableAdapter
        '
        Me.ClassLevelTableAdapter.ClearBeforeFill = True
        '
        'InstructorTableAdapter
        '
        Me.InstructorTableAdapter.ClearBeforeFill = True
        '
        'ResortTableAdapter
        '
        Me.ResortTableAdapter.ClearBeforeFill = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(89, 192)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Student: "
        '
        'ComboBox_student
        '
        Me.ComboBox_student.DataSource = Me.StudentBindingSource
        Me.ComboBox_student.DisplayMember = "FirstName"
        Me.ComboBox_student.FormattingEnabled = True
        Me.ComboBox_student.Location = New System.Drawing.Point(189, 185)
        Me.ComboBox_student.Name = "ComboBox_student"
        Me.ComboBox_student.Size = New System.Drawing.Size(149, 21)
        Me.ComboBox_student.TabIndex = 22
        Me.ComboBox_student.ValueMember = "StudentID"
        '
        'StudentBindingSource
        '
        Me.StudentBindingSource.DataMember = "Student"
        Me.StudentBindingSource.DataSource = Me.SkiResortDataSet
        '
        'StudentTableAdapter
        '
        Me.StudentTableAdapter.ClearBeforeFill = True
        '
        'Label_expense
        '
        Me.Label_expense.AutoSize = True
        Me.Label_expense.Location = New System.Drawing.Point(608, 488)
        Me.Label_expense.Name = "Label_expense"
        Me.Label_expense.Size = New System.Drawing.Size(86, 13)
        Me.Label_expense.TabIndex = 23
        Me.Label_expense.Text = "Total Expenses: "
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 27)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(146, 148)
        Me.PictureBox1.TabIndex = 24
        Me.PictureBox1.TabStop = False
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(623, 66)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(115, 36)
        Me.Button2.TabIndex = 25
        Me.Button2.Text = "Close"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AgentToolStripMenuItem, Me.ManagerToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(796, 24)
        Me.MenuStrip1.TabIndex = 26
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'AgentToolStripMenuItem
        '
        Me.AgentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentToolStripMenuItem, Me.ClassToolStripMenuItem})
        Me.AgentToolStripMenuItem.Name = "AgentToolStripMenuItem"
        Me.AgentToolStripMenuItem.Size = New System.Drawing.Size(51, 20)
        Me.AgentToolStripMenuItem.Text = "Agent"
        '
        'ManagerToolStripMenuItem
        '
        Me.ManagerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SearchToolStripMenuItem, Me.ClassLevelToolStripMenuItem})
        Me.ManagerToolStripMenuItem.Name = "ManagerToolStripMenuItem"
        Me.ManagerToolStripMenuItem.Size = New System.Drawing.Size(66, 20)
        Me.ManagerToolStripMenuItem.Text = "Manager"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'StudentToolStripMenuItem
        '
        Me.StudentToolStripMenuItem.Name = "StudentToolStripMenuItem"
        Me.StudentToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.StudentToolStripMenuItem.Text = "Student"
        '
        'ClassToolStripMenuItem
        '
        Me.ClassToolStripMenuItem.Name = "ClassToolStripMenuItem"
        Me.ClassToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ClassToolStripMenuItem.Text = "Class"
        '
        'SearchToolStripMenuItem
        '
        Me.SearchToolStripMenuItem.Name = "SearchToolStripMenuItem"
        Me.SearchToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.SearchToolStripMenuItem.Text = "Search"
        '
        'ClassLevelToolStripMenuItem
        '
        Me.ClassLevelToolStripMenuItem.Name = "ClassLevelToolStripMenuItem"
        Me.ClassLevelToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ClassLevelToolStripMenuItem.Text = "ClassLevel"
        '
        'SearchForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(796, 510)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label_expense)
        Me.Controls.Add(Me.ComboBox_student)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DateTimePicker_End)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.DateTimePicker_Start)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "SearchForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Search Classes"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClassLevelBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SkiResortDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.InstructorBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ResortBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClassDetailBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents DateTimePicker_Start As DateTimePicker
    Friend WithEvents DateTimePicker_End As DateTimePicker
    Friend WithEvents Label4 As Label
    Friend WithEvents SkiResortDataSet As SkiResortDataSet
    Friend WithEvents ClassDetailBindingSource As BindingSource
    Friend WithEvents Class_DetailTableAdapter As SkiResortDataSetTableAdapters.Class_DetailTableAdapter
    Friend WithEvents ClassLevelBindingSource As BindingSource
    Friend WithEvents ClassLevelTableAdapter As SkiResortDataSetTableAdapters.ClassLevelTableAdapter
    Friend WithEvents InstructorBindingSource As BindingSource
    Friend WithEvents InstructorTableAdapter As SkiResortDataSetTableAdapters.InstructorTableAdapter
    Friend WithEvents ResortBindingSource As BindingSource
    Friend WithEvents ResortTableAdapter As SkiResortDataSetTableAdapters.ResortTableAdapter
    Friend WithEvents ClassIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ClassNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PriceDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents LevelIDDataGridViewTextBoxColumn As DataGridViewComboBoxColumn
    Friend WithEvents InstructorIDDataGridViewTextBoxColumn As DataGridViewComboBoxColumn
    Friend WithEvents ResortIDDataGridViewTextBoxColumn As DataGridViewComboBoxColumn
    Friend WithEvents EnrollmentDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox_student As ComboBox
    Friend WithEvents StudentBindingSource As BindingSource
    Friend WithEvents StudentTableAdapter As SkiResortDataSetTableAdapters.StudentTableAdapter
    Friend WithEvents Label_expense As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button2 As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents AgentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ManagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StudentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClassToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SearchToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClassLevelToolStripMenuItem As ToolStripMenuItem
End Class
