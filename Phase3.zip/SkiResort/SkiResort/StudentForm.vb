﻿Public Class StudentForm
    Private Sub Instructor_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.GenderTableAdapter.Fill(Me.SkiResortDataSet.Gender)
    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs)

        Me.Validate()

    End Sub

    Dim IsAdding As Boolean = False
    Private Sub BindingNavigatorAddNewItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorAddNewItem.Click
        IsAdding = True
    End Sub

    Public Sub FillByStudentId(value As Integer)
        Try
            Console.WriteLine(value)
            Me.StudentTableAdapter.FillByStudentID(Me.SkiResortDataSet.Student, value)
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub FillByStudentIDToolStripButton_Click(sender As Object, e As EventArgs) Handles FillByStudentIDToolStripButton.Click
        Try
            Me.StudentTableAdapter.FillByStudentID(Me.SkiResortDataSet.Student, CType(StudentIDToolStripTextBox.Text, Integer))
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub StudentBindingSource_CurrentItemChanged(sender As Object, e As EventArgs) Handles StudentBindingSource.CurrentItemChanged
        If (IsAdding) Then
            Try
                Dim cmd As New Data.SqlClient.SqlCommand
                cmd.CommandText = "SELECT Max(StudentID) AS MaxID FROM [Student]"
                cmd.CommandType = CommandType.Text
                Dim i As Integer
                cmd.Connection.Open()
                i = cmd.ExecuteScalar() + 1
                cmd.Connection.Close()
                Me.StudentIDTextBox.Text = i.ToString
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    Private Sub ToolStripButton1_Click_1(sender As Object, e As EventArgs) Handles ToolStripButton1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub StudentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentToolStripMenuItem.Click
        Try
            Dim Student As New StudentForm
            Student.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ClassLevelToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClassLevelToolStripMenuItem.Click
        Try
            Dim ClassLevelToolStripMenuItem As New ClassLevelForm
            ClassLevelToolStripMenuItem.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ClassToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClassToolStripMenuItem.Click
        Try
            Dim ClassLevelToolStripMenuItem As New ClassForm
            ClassLevelToolStripMenuItem.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub SeachToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SeachToolStripMenuItem.Click
        Try
            Dim SearchToolStripMenuItem1 As New SearchForm
            SearchToolStripMenuItem1.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class