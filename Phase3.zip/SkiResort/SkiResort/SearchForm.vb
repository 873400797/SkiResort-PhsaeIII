﻿Public Class SearchForm
    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Me.ClassLevelTableAdapter.Fill(Me.SkiResortDataSet.ClassLevel)
            Me.ResortTableAdapter.Fill(Me.SkiResortDataSet.Resort)
            Me.InstructorTableAdapter.Fill(Me.SkiResortDataSet.Instructor)
            Me.StudentTableAdapter.Fill(Me.SkiResortDataSet.Student)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Console.WriteLine(DateTimePicker_Start.Value.ToShortDateString())
            Me.Class_DetailTableAdapter.FillBy(Me.SkiResortDataSet.Class_Detail, DateTimePicker_End.Value.ToShortDateString(), DateTimePicker_Start.Value.ToShortDateString(), CType(ComboBox_student.SelectedValue, Integer))

            Dim money As Double
            For i As Int32 = 0 To DataGridView1.Rows.Count - 1
                money = money + DataGridView1.Rows(i).Cells(2).Value
            Next
            Label_expense.Text = "Total Expenses: $" + money.ToString()
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub StudentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentToolStripMenuItem.Click
        Try
            Dim Student As New StudentForm
            Student.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ClassToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClassToolStripMenuItem.Click
        Try
            Dim ClassLevelToolStripMenuItem As New ClassForm
            ClassLevelToolStripMenuItem.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub SearchToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SearchToolStripMenuItem.Click
        Try
            Dim SearchToolStripMenuItem1 As New SearchForm
            SearchToolStripMenuItem1.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub ClassLevelToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClassLevelToolStripMenuItem.Click
        Try
            Dim ClassLevelToolStripMenuItem As New ClassLevelForm
            ClassLevelToolStripMenuItem.Show()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
